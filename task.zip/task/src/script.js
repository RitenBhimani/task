var swiper = new Swiper('.swiper-container', {
    direction: 'horizontal', // Horizontal scrolling
    loop: true,              // Infinite loop
    slidesPerView: 1,        // Number of slides to display
    spaceBetween: 20,        // Space between the slides
    autoplay: {
        delay: 3000,         // Auto slide every 3 seconds
        disableOnInteraction: false, // Keep autoplay running even after user interaction
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    pagination: {
        el: '.swiper-pagination',
        clickable: true,     // Enable clicking on pagination dots
    },
    speed: 600,              // Smooth transition speed (in ms)
    breakpoints: {
        768: {
            slidesPerView: 2, // Show 2 slides on medium screens
            spaceBetween: 30, // Adjust space between slides
        },
        1024: {
            slidesPerView: 3, // Show 3 slides on larger screens
            spaceBetween: 40, // Adjust space between slides
        },
    },
});